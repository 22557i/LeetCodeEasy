package exam0407.q3;

public class Instructor {
    private Name nm;
    private String title;

    Instructor(Name nm, String title){
        this.nm = nm;
        this.title = title;
    }

    @Override
    public String toString() {
        return "Instructor{" +
                "nm=" + nm +
                ", title='" + title + '\'' +
                '}';
    }

    public boolean equals(Instructor other){
        return this.nm.equals(other.getLastName()) && this.title.equals(other.title);
    }

    public String getLastName(){
        return this.nm.getLast();
    }
}
class Name {
    public boolean equals(Name other);
    public String toString();
    public String getLast();
}

